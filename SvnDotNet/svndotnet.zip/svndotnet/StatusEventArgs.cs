using System;
using System.Collections.Generic;
using System.Text;

namespace PumaCode.SvnDotNet {
    public class StatusEventArgs : EventArgs {
    }
}

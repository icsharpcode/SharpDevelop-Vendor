using System;
using System.Collections.Generic;
using System.Text;

namespace PumaCode.SvnDotNet.UnitTests.SubversionSharp {
    internal struct TestLogData {
        public string Author;
        public string DateString;
        public string Message;
    }
}

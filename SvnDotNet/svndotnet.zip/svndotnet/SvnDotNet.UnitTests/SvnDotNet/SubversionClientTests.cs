using System;
using System.Collections.Generic;
using System.Text;

using NUnit.Framework;

namespace PumaCode.SvnDotNet.UnitTests.SvnDotNet {
    [TestFixture]
    public class SubversionClientTests {

    }
}

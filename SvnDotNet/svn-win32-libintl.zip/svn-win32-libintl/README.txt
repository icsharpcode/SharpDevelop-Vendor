This is the modified GNU libintl used by Subversion on Win32. It is
based on the gettext-0.14.1 sources provided by the GnuWin32
project. The file diff-0.14.1.txt shows the changes that were made to
build this library.


// PartCover.CorDriver.cpp : Implementation of DLL Exports.
#include "stdafx.h"
#include "resource.h"

[module(
        type=dll
        ,name="PartCover"
        ,uuid="7D0E6AAB-C5FC-4103-AAD4-8BF3112A56C4"
        ,version="2.0"
        ,helpstring="PartCover module"
        ,resource_name="IDR_PARTCOVERCORDRIVER"
        )]
class CPartCoverCorDriverModule
{
};

﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using AvalonDock;
using System.ComponentModel;
using System.IO;
using System.Reflection;
using System.Xml;
using System.Windows.Forms.Integration;
using System.Windows.Interop;
using System.Diagnostics;

namespace AvalonDockTest
{
    /// <summary>
    /// Interaction logic for Demo.xaml
    /// </summary>
    public partial class Demo : Window
    {
        WindowsFormsHost _PropGridHost = new WindowsFormsHost();

        public Demo()
        {


            InitializeComponent();

            _dockingManager.ApplyTemplate();

            string path = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                 + @"\AvalonDockTest.Layout.xml";
            if (!File.Exists(path))
                return;

            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            //_dockingManager.RestoreLayout(fs);

            fs.Close();
            
            DependencyPropertyDescriptor prop =
                DependencyPropertyDescriptor.FromProperty(DockableContent.StatePropertyKey.DependencyProperty, typeof(DockableContent));
            prop.AddValueChanged(_propertiesWindow, this.OnLogEventStateChanged);
            prop.AddValueChanged(_explorerWindow, this.OnLogEventStateChanged);
            prop.AddValueChanged(_eventsLogWindow, this.OnLogEventStateChanged);

            _dockingManager.PropertyChanged += new PropertyChangedEventHandler(_dockingManager_PropertyChanged);


            System.Windows.Forms.PropertyGrid _PropGrid = new System.Windows.Forms.PropertyGrid();
            _PropGrid.SelectedObject = _dockingManager;

            _PropGrid.Name = "_PropertyGrid";

            _PropGridHost.Child = _PropGrid;

            this._objectExplorerHost.Content = _PropGridHost;
            _PropGridHost.GotKeyboardFocus += new KeyboardFocusChangedEventHandler(_PropGridHost_GotKeyboardFocus);
            //((IKeyboardInputSink)_PropGridHost)

            DockableContent cnt = new DockableContent();
            cnt.Title = "Test";
            cnt.Name = "test";
            WindowsFormsHost tempHost = new WindowsFormsHost();
            tempHost.Child = new System.Windows.Forms.TextBox();
            cnt.Content = tempHost;
            _dockingManager.Show(cnt, DockableContentState.Docked, AnchorStyle.Left);
        }

        void _PropGridHost_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        {
            
        }


        private void NewDocuments_Click(object sender, RoutedEventArgs e)
        {
            int i = 1;



            int baseCount = _dockingManager.Documents.Length;
            while (i <= 4)
            {
                //DocumentContent doc = new DocumentContent();
                //doc.Title = "Document " + (i + baseCount);
                //doc.InfoTip = "Info tipo for " + doc.Title;
                //doc.ContentTypeDescription = "Sample document";
                //doc.Content = new DemoDocument();
                DemoDocument doc = new DemoDocument();
                doc.Title = "Document " + (i + baseCount);
                doc.InfoTip = "Info tipo for " + doc.Title;
                doc.ContentTypeDescription = "Sample document";
                doc.Closing += new EventHandler<CancelEventArgs>(doc_Closing);
                doc.Closed += new EventHandler(doc_Closed);
                _documentsHost.Items.Add(doc);
                i++;
            }
        }

        void doc_Closed(object sender, EventArgs e)
        {
            Debug.WriteLine(((DocumentContent)sender).Title + " closed");
        }

        void doc_Closing(object sender, CancelEventArgs e)
        {
            Debug.WriteLine(((DocumentContent)sender).Title + " closing");
        }

        void page_Loaded(object sender, RoutedEventArgs e)
        {
            ((Frame)sender).NavigationService.Navigate("http:\\www.google.com");
        }

        private void ShowProperties_Click(object sender, RoutedEventArgs e)
        {
            Hyperlink link = sender as Hyperlink;
            if (link.Name == "ShowProperties_AutoHide")
                ShowWindow(_propertiesWindow, DockableContentState.AutoHide);
            else if (link.Name == "ShowProperties_FloatingWindow")
                ShowWindow(_propertiesWindow, DockableContentState.FloatingWindow);
            else
                ShowWindow(_propertiesWindow, DockableContentState.Docked);
        }

        private void ShowExplorer_Click(object sender, RoutedEventArgs e)
        {
            Hyperlink link = sender as Hyperlink;
            if (link.Name == "ShowExplorer_AutoHide")
                ShowWindow(_explorerWindow, DockableContentState.AutoHide);
            else if (link.Name == "ShowExplorer_FloatingWindow")
                ShowWindow(_explorerWindow, DockableContentState.FloatingWindow);
            else
                ShowWindow(_explorerWindow, DockableContentState.Docked);
        }

        private void ShowEventsLog_Click(object sender, RoutedEventArgs e)
        {
            Hyperlink link = sender as Hyperlink;
            if (link.Name == "ShowEventsLog_AutoHide")
                ShowWindow(_eventsLogWindow, DockableContentState.AutoHide);
            else if (link.Name == "ShowEventsLog_FloatingWindow")
                ShowWindow(_eventsLogWindow, DockableContentState.FloatingWindow);
            else
                _dockingManager.Show(_eventsLogWindow, DockableContentState.Docked, AnchorStyle.Right);
        }

        private void ShowProperty_Click(object sender, RoutedEventArgs e)
        {
            Hyperlink link = sender as Hyperlink;
            if (link.Name == "ShowProperty_AutoHide")
                ShowWindow(_objectExplorerHost, DockableContentState.AutoHide);
            else if (link.Name == "ShowProperty_FloatingWindow")
                ShowWindow(_objectExplorerHost, DockableContentState.FloatingWindow);
            else
                _dockingManager.Show(_objectExplorerHost, DockableContentState.Docked, AnchorStyle.Right);
        }

        void ShowWindow(DockableContent contentToShow, DockableContentState desideredState)
        {
            if (desideredState == DockableContentState.AutoHide ||
                desideredState == DockableContentState.FloatingWindow)
            {
                _dockingManager.Show(contentToShow, desideredState);
            }
            else
                _dockingManager.Show(contentToShow, DockableContentState.Docked);
        }


        void OnLogEventStateChanged(object sender, EventArgs e)
        {
            DockableContent content = sender as DockableContent;

            _txtLog.AppendText(
                string.Format("[{0}] '{1}' changed state to '{2}'", DateTime.Now.ToLongTimeString(), content.Title, content.State));
            _txtLog.AppendText(Environment.NewLine);
            _txtLog.ScrollToEnd();
        }

        void _dockingManager_PropertyChanged(object sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == "ActiveContent" && _dockingManager.ActiveContent != null)
            {
                if (_dockingManager.ActiveContent != null)
                {
                    _txtLog.AppendText(
                        string.Format("[{0}] '{1}' is the active content", DateTime.Now.ToLongTimeString(), _dockingManager.ActiveContent.Title));
                
                    _txtLog.AppendText(Environment.NewLine);
                    _txtLog.ScrollToEnd();
                }
            }
        }

        private void Window_Closing(object sender, CancelEventArgs e)
        {
            if (_dockingManager != null)
                _dockingManager.PropertyChanged -= new PropertyChangedEventHandler(_dockingManager_PropertyChanged);
            
            DependencyPropertyDescriptor prop =
                DependencyPropertyDescriptor.FromProperty(DockableContent.StatePropertyKey.DependencyProperty, typeof(DockableContent));
            prop.RemoveValueChanged(_propertiesWindow, this.OnLogEventStateChanged);
            prop.RemoveValueChanged(_explorerWindow, this.OnLogEventStateChanged);
            prop.RemoveValueChanged(_eventsLogWindow, this.OnLogEventStateChanged);

            string path = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                + @"\AvalonDockTest.Layout.xml";

            _dockingManager.SaveLayout(path);
        }

        private void SaveLayout_Click(object sender, RoutedEventArgs e)
        {
            //DockableContent cnt = new DockableContent();
            //cnt.Content = new TextBox();
            //cnt.Title = "Camera";

            //DockablePane pane = new DockablePane();
            //pane.Items.Add(cnt);

            //_dockingManager.Show(cnt, DockableContentState.Document);
            //_dockingManager.Show(cnt, DockableContentState.FloatingWindow);

            //FloatingWindow fltWindow = Window.GetWindow(cnt) as FloatingWindow;
            //fltWindow.Left = 100;
            //fltWindow.Top = 100;
            //fltWindow.Width = 300;
            //fltWindow.Height = 300;


            string path = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                + @"\AvalonDockTest.Layout.xml";

            _dockingManager.SaveLayout(path);

            
        }

        private void RestoreLayout_Click(object sender, RoutedEventArgs e)
        {
            string path = System.IO.Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location)
                + @"\AvalonDockTest.Layout.xml";
            if (!File.Exists(path))
                return;

            FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
            _dockingManager.RestoreLayout(fs);

            fs.Close();
        }

        private void ShowDockingManager_Checked(object sender, RoutedEventArgs e)
        {
            //test the load/unload event putting docking manager out of the logical/visual tree
            TestContainer.Content = ShowDockingManager.IsChecked ? null : _dockingManager;
        }

        private void CommandBinding_CanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            e.Handled=true;
            e.CanExecute = false;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
 

        }



    }
}

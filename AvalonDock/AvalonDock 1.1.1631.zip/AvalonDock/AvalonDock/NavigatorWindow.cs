﻿//Copyright (c) 2007, Adolfo Marinucci
//All rights reserved.

//Redistribution and use in source and binary forms, with or without modification, 
//are permitted provided that the following conditions are met:
//
//* Redistributions of source code must retain the above copyright notice, 
//  this list of conditions and the following disclaimer.
//* Redistributions in binary form must reproduce the above copyright notice, 
//  this list of conditions and the following disclaimer in the documentation 
//  and/or other materials provided with the distribution.
//* Neither the name of Adolfo Marinucci nor the names of its contributors may 
//  be used to endorse or promote products derived from this software without 
//  specific prior written permission.
//
//THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
//AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
//WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
//IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
//INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
//PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
//HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
//OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
//EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;

namespace AvalonDock
{
    public class NavigatorWindow : Window, INotifyPropertyChanged
    {
        static NavigatorWindow()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(NavigatorWindow), new FrameworkPropertyMetadata(typeof(NavigatorWindow)));


            Window.AllowsTransparencyProperty.OverrideMetadata(typeof(NavigatorWindow), new FrameworkPropertyMetadata(true));
            Window.WindowStyleProperty.OverrideMetadata(typeof(NavigatorWindow), new FrameworkPropertyMetadata(WindowStyle.None));
            Window.ShowInTaskbarProperty.OverrideMetadata(typeof(NavigatorWindow), new FrameworkPropertyMetadata(false));
            Control.BackgroundProperty.OverrideMetadata(typeof(NavigatorWindow), new FrameworkPropertyMetadata(Brushes.Transparent));
        }


        public NavigatorWindow()
        { }

        DockingManager _manager;
        public NavigatorWindow(DockingManager manager)
        {
            _manager = manager;

        }

        protected override void OnActivated(EventArgs e)
        {
            base.OnActivated(e);
           
            Documents = _manager.FindContents<DocumentContent>();
            DockableContents = _manager.FindContents<DockableContent>();
            SelectedContent = _manager.ActiveDocument;
            SelectedToolWindow = null;
        }

        protected override void OnDeactivated(EventArgs e)
        {
            //SelectedContent = null;
            base.OnDeactivated(e);
        }

        List<DocumentContent> _documents = null;

        public List<DocumentContent> Documents
        {
            get { return _documents; }
            private set { _documents = value; NotifyPropertyChanged("Documents"); }
        }

        List<DockableContent> _tools = null;

        public List<DockableContent> DockableContents
        {
            get { return _tools; }
            private set { _tools = value; NotifyPropertyChanged("DockableContents"); }
        }

        DocumentContent _selectedContent;

        public DocumentContent SelectedContent
        {
            get 
            {
                return _selectedContent; 
            }
            set
            {
                if (_selectedContent != value)
                {
                     _selectedContent = value;
                    NotifyPropertyChanged("SelectedContent");
                }
            }
        }

        DockableContent _toolContent;

        public DockableContent SelectedToolWindow
        {
            get
            {
                return _toolContent;
            }
            set
            {
                if (_toolContent != value)
                {
                    _toolContent = value;

                    NotifyPropertyChanged("SelectedToolWindow");

                    if (_toolContent != null)
                        SelectContentAndHideWindow(_toolContent);
                }
            }
        }

        void SelectContentAndHideWindow(DockableContent contentToSelect)
        {
            _manager.Show(contentToSelect);
            Hide();
        }

        public void MoveNextSelectedContent()
        {
            if (_selectedContent == null)
                return;

            if (Documents.Contains(SelectedContent))
            {
                int indexOfSelecteContent = Documents.IndexOf(_selectedContent);

                if (indexOfSelecteContent == Documents.Count - 1)
                {
                    indexOfSelecteContent = 0;
                }
                else
                    indexOfSelecteContent++;

                SelectedContent = Documents[indexOfSelecteContent];
            }
            //else if (DockableContents.Contains(SelectedContent as DockableContent))
            //{
            //    int indexOfSelecteContent = DockableContents.IndexOf(SelectedContent as DockableContent);

            //    if (indexOfSelecteContent == DockableContents.Count - 1)
            //    {
            //        indexOfSelecteContent = 0;
            //    }
            //    else
            //        indexOfSelecteContent++;

            //    SelectedContent = DockableContents[indexOfSelecteContent];
            //}

        }




        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}

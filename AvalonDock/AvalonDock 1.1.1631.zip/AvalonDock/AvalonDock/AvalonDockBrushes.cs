﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AvalonDock
{
    public enum AvalonDockBrushes
    {
        DockablePaneTitleBackground,

        DockablePaneTitleBackgroundSelected,

        DockablePaneTitleForeground,

        DockablePaneTitleForegroundSelected,

        PaneHeaderCommandBackground,

        PaneHeaderCommandBorderBrush,

        DocumentHeaderBackground,

        DocumentHeaderForeground,

        DocumentHeaderBackgroundSelected,

        DocumentHeaderBackgroundMouseOver,
    }
}

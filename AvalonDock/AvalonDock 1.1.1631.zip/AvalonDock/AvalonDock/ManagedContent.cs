//Copyright (c) 2007, Adolfo Marinucci
//All rights reserved.

//Redistribution and use in source and binary forms, with or without modification, 
//are permitted provided that the following conditions are met:
//
//* Redistributions of source code must retain the above copyright notice, 
//  this list of conditions and the following disclaimer.
//* Redistributions in binary form must reproduce the above copyright notice, 
//  this list of conditions and the following disclaimer in the documentation 
//  and/or other materials provided with the distribution.
//* Neither the name of Adolfo Marinucci nor the names of its contributors may 
//  be used to endorse or promote products derived from this software without 
//  specific prior written permission.
//
//THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" 
//AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
//WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. 
//IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
//INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, 
//PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) 
//HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
//OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, 
//EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE. 

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Xml;
using System.Windows.Forms.Integration;
using System.Diagnostics;
using System.Windows.Threading;
using System.Threading;
using System.Reflection;


namespace AvalonDock
{
    
    public abstract class ManagedContent : System.Windows.Controls.ContentControl, INotifyPropertyChanged
    {
        static ManagedContent()
        {
            //This OverrideMetadata call tells the system that this element wants to provide a style that is different than its base class.
            //This style is defined in themes\generic.xaml
            //DefaultStyleKeyProperty.OverrideMetadata(typeof(ManagedContent), new FrameworkPropertyMetadata(typeof(ManagedContent)));
            FocusableProperty.OverrideMetadata(typeof(ManagedContent), new FrameworkPropertyMetadata(true));
        }

        public ManagedContent()
        {
            this.Loaded += new RoutedEventHandler(ManagedContent_Loaded);
            this.Unloaded += new RoutedEventHandler(ManagedContent_Unloaded);
        }


        void ManagedContent_Loaded(object sender, RoutedEventArgs e)
        {
            //if (Manager == null)
            //    throw new InvalidOperationException("ManagedContent must be put under a DockingManager!");
        }

        void ManagedContent_Unloaded(object sender, RoutedEventArgs e)
        {
            //Content = null;
        }

        //protected override void OnContentChanged(object oldContent, object newContent)
        //{
        //    if (oldContent is WindowsFormsHost)
        //    {
        //        WindowsFormsHost contentHost = oldContent as WindowsFormsHost;
        //        IsFocusWithInWinFormsControl = false;
        //        contentHost.GotKeyboardFocus -= new KeyboardFocusChangedEventHandler(contentHost_GotKeyboardFocus);
        //        contentHost.LostKeyboardFocus -= new KeyboardFocusChangedEventHandler(contentHost_LostKeyboardFocus);
        //    }
        //    if (newContent is WindowsFormsHost)
        //    {
        //        WindowsFormsHost contentHost = newContent as WindowsFormsHost;
        //        IsFocusWithInWinFormsControl = contentHost.IsKeyboardFocusWithin;
        //        contentHost.GotKeyboardFocus += new KeyboardFocusChangedEventHandler(contentHost_GotKeyboardFocus);
        //        contentHost.LostKeyboardFocus += new KeyboardFocusChangedEventHandler(contentHost_LostKeyboardFocus);
        //    }
            
        //    base.OnContentChanged(oldContent, newContent);
        //}

        //void contentHost_LostKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        //{
        //    //WindowsFormsHost contentHost = this.Content as WindowsFormsHost;
        //    //Debug.WriteLine(contentHost.Child);
        //    //Debug.WriteLine(contentHost.Child.Focused.ToString());

        //    //if (e.NewFocus != null &&
        //    //    e.NewFocus != this.Content)
        //    //    IsFocusWithInWinFormsControl = false;
        //}

        //void contentHost_GotKeyboardFocus(object sender, KeyboardFocusChangedEventArgs e)
        //{
        //    //IsFocusWithInWinFormsControl = e.NewFocus == this.Content;
        //}

        public string Title
        {
            get { return (string)GetValue(TitleProperty); }
            set { SetValue(TitleProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Title.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty TitleProperty =
            DependencyProperty.Register("Title", typeof(string), typeof(ManagedContent));

        public string IconSource
        {
            get { return (string)GetValue(IconSourceProperty); }
            set { SetValue(IconSourceProperty, value); }
        }

        // Using a DependencyProperty as the backing store for Icon.  This enables animation, styling, binding, etc...
        public static readonly DependencyProperty IconSourceProperty =
            DependencyProperty.Register("IconSource", typeof(string), typeof(ManagedContent));



        //public bool IsSelected
        //{
        //    get { return (bool)GetValue(IsSelectedProperty); }
        //    set { SetValue(IsSelectedProperty, value); }
        //}

        //// Using a DependencyProperty as the backing store for IsSelected.  This enables animation, styling, binding, etc...
        //public static readonly DependencyProperty IsSelectedProperty =
        //    DependencyProperty.Register("IsSelected", typeof(bool), typeof(ManagedContent));


        //protected override void OnPropertyChanged(DependencyPropertyChangedEventArgs e)
        //{
        //    base.OnPropertyChanged(e);
           
        //    if (e.Property == IsSelectedProperty && (bool)e.NewValue)
        //    {
        //        if (ContainerPane != null)
        //        {
        //            //ContainerPane.ActiveContent = this;
        //            ContainerPane.SelectedItem = this;
        //        }
        //    }
        //}

        FrameworkElement _dragEnabledArea;

        protected FrameworkElement DragEnabledArea
        {
            get { return _dragEnabledArea; }
        }

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            _dragEnabledArea = GetTemplateChild("PART_DragArea") as FrameworkElement;

            if (_dragEnabledArea != null)
            {
                _dragEnabledArea.MouseDown += new MouseButtonEventHandler(OnDragMouseDown);
                _dragEnabledArea.MouseMove += new MouseEventHandler(OnDragMouseMove);
                _dragEnabledArea.MouseUp += new MouseButtonEventHandler(OnDragMouseUp);
                _dragEnabledArea.MouseLeave += new MouseEventHandler(OnDragMouseLeave);
            }
        }


        #region Mouse management

        protected virtual void OnDragStart(Point ptMouse, Point ptrelativeMouse)
        {
        
        }

        Point ptStartDrag;
        bool isMouseDown = false;

        protected Point StartDragPoint
        {
            get { return ptStartDrag; }
        }

        protected bool IsMouseDown
        {
            get { return isMouseDown; }
        }

        protected void ResetIsMouseDownFlag()
        {
            isMouseDown = false;
        }

        protected virtual void OnDragMouseDown(object sender, MouseButtonEventArgs e)
        {
            if (!e.Handled && Manager != null)// && State != DockableContentState.AutoHide)
            {
                isMouseDown = true;
                //ptStartDrag = e.GetPosition(this);
                ptStartDrag = e.GetPosition((IInputElement)System.Windows.Media.VisualTreeHelper.GetParent(this));
                //FocusContent();
            }
        }

        protected virtual void OnDragMouseMove(object sender, MouseEventArgs e)
        {
        }

        protected virtual void OnDragMouseUp(object sender, MouseButtonEventArgs e)
        {
            isMouseDown = false;
        }

        Point ptRelativePosition;

        protected virtual void OnDragMouseLeave(object sender, MouseEventArgs e)
        {
            if (!e.Handled && IsMouseDown && Manager != null)
            {
                if (!IsMouseCaptured)
                {
                    Point ptMouseMove = e.GetPosition(this);
                    ManagedContent contentToSwap = null;
                    if (ContainerPane != null)
                    {
                        foreach (ManagedContent content in ContainerPane.Items)
                        {
                            if (content == this)
                                continue;

                            HitTestResult res = VisualTreeHelper.HitTest(content, e.GetPosition(content));
                            if (res != null)
                            {
                                contentToSwap = content;
                                break;
                            }

                        }
                    }

                    if (Math.Abs(ptMouseMove.X - StartDragPoint.X) > SystemParameters.MinimumHorizontalDragDistance ||
                        Math.Abs(ptMouseMove.Y - StartDragPoint.Y) > SystemParameters.MinimumVerticalDragDistance)
                        ptRelativePosition = e.GetPosition(DragEnabledArea);


                    if (contentToSwap != null)
                    {
                        Pane containerPane = ContainerPane;
                        int myIndex = containerPane.Items.IndexOf(this);

                        ContainerPane.Items.RemoveAt(myIndex);

                        int otherIndex = containerPane.Items.IndexOf(contentToSwap);
                        containerPane.Items.RemoveAt(otherIndex);

                        containerPane.Items.Insert(otherIndex, this);

                        containerPane.Items.Insert(myIndex, contentToSwap);

                        containerPane.SelectedItem = this;

                        e.Handled = false;
                        return;
                    }
                    else if (Math.Abs(ptMouseMove.X - StartDragPoint.X) > SystemParameters.MinimumHorizontalDragDistance ||
                        Math.Abs(ptMouseMove.Y - StartDragPoint.Y) > SystemParameters.MinimumVerticalDragDistance)
                    {
                        ResetIsMouseDownFlag();
                        OnDragStart(StartDragPoint, ptRelativePosition);
                        e.Handled = true;
                    }
                }
            }
            
            isMouseDown = false;
        }


        #endregion

        protected override void OnMouseDown(MouseButtonEventArgs e)
        {
            base.OnMouseDown(e);

            if (!e.Handled)
            {
                //SetValue(IsSelectedProperty, true);
                //Selector.SetIsSelected(this, true);
                if (ContainerPane != null)
                {
                    //Keyboard.Focus(this.Content as IInputElement);
                    ContainerPane.SelectedItem = this;
                    ContainerPane.Focus();
                    if (Manager != null)
                        Manager.ActiveContent = this;
                    //Keyboard.Focus(this.Content as IInputElement);
                    //this.Focus();
                    //FocusManager.SetFocusedElement(Window.GetWindow(this), this.Content as IInputElement);
                    //this.Focus
                }
            }

        }

        protected override void OnPreviewMouseDown(MouseButtonEventArgs e)
        {
            base.OnPreviewMouseDown(e);
        }

        protected override void OnKeyDown(KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (ContainerPane != null)
                    ContainerPane.SelectedItem = this;
            }

            base.OnKeyDown(e);
        }

        public Pane ContainerPane
        {
            get 
            {
                Pane containerPane = Parent as Pane;
                if (containerPane != null)
                    return containerPane;

                return this.FindVisualAncestor<Pane>(false);
            }
        }

        internal DockingManager Manager
        {
            get 
            {
                if (ContainerPane != null)
                    return ContainerPane.GetManager();

                return null;
            }
        }



        protected override void OnGotKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            base.OnGotKeyboardFocus(e);

            if (Manager != null)
                Manager.ActiveContent = this;
        }

        protected override void OnLostKeyboardFocus(KeyboardFocusChangedEventArgs e)
        {
            base.OnLostKeyboardFocus(e);
        }


        ///// <summary>
        ///// Move logical focus to the content of the item
        ///// </summary>
        //internal virtual void FocusContent()
        //{

        //}


        bool _isActiveContent = false;
        public bool IsActiveContent
        {
            get 
            {
                return _isActiveContent;  
            }
            set 
            {
                if (_isActiveContent != value)
                {
                    _isActiveContent = value;
                    NotifyPropertyChanged("IsActiveContent");

                    if (_isActiveContent && !IsKeyboardFocused)
                    {
                        Dispatcher.BeginInvoke(DispatcherPriority.Input, new ThreadStart(delegate
                        {
                            if (_isActiveContent && !IsKeyboardFocused)
                            {
                                if (this.Content is WindowsFormsHost)
                                {
                                    //Use reflection in order to remove WinForms assembly reference
                                    WindowsFormsHost contentHost = this.Content as WindowsFormsHost;

                                    object childCtrl = contentHost.GetType().GetProperty("Child").GetValue(contentHost, null);

                                    if (childCtrl != null)
                                    {
                                        Type winFormType = childCtrl.GetType();

                                        bool focused = (bool)winFormType.GetProperty("Focused").GetValue(childCtrl, null);
                                        if (!focused)
                                        {
                                            winFormType.GetMethod("Focus").Invoke(childCtrl, null);
                                        }
                                    }

                                    //if (contentHost.Child != null && !contentHost.Child.Focused)
                                    //    contentHost.Child.Focus();
                                }
                                else if (this.Content is IInputElement)
                                {
                                    Debug.WriteLine("Try to set kb focus to " + this.Content.ToString());
                                    IInputElement kbFocused = Keyboard.Focus(this.Content as IInputElement);
                                    if (kbFocused != null)
                                        Debug.WriteLine("Focused element " + kbFocused.ToString());
                                    else
                                        Debug.WriteLine("No focused element");
                                }
                            }
                        }));
                    }
                }
            
            }
        }


        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;

        protected void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion



    }
}

using System;
using System.Windows;
using System.Data;
using System.Xml;
using System.Configuration;
using System.Diagnostics;
using System.Windows.Controls;

namespace AvalonDockTest
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>

    public partial class App : System.Windows.Application
    {

        private void Application_LoadCompleted(object sender, System.Windows.Navigation.NavigationEventArgs e)
        {

        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            PresentationTraceSources.ResourceDictionarySource.Listeners.Add(new ConsoleTraceListener());
            PresentationTraceSources.ResourceDictionarySource.Switch.Level = SourceLevels.All;
            PresentationTraceSources.DataBindingSource.Listeners.Add(new ConsoleTraceListener());
            PresentationTraceSources.DataBindingSource.Switch.Level = SourceLevels.Error;
            PresentationTraceSources.DependencyPropertySource.Listeners.Add(new ConsoleTraceListener());
            PresentationTraceSources.DependencyPropertySource.Switch.Level = SourceLevels.All;
            PresentationTraceSources.DocumentsSource.Listeners.Add(new ConsoleTraceListener());
            PresentationTraceSources.DocumentsSource.Switch.Level = SourceLevels.All;
            PresentationTraceSources.MarkupSource.Listeners.Add(new ConsoleTraceListener());
            PresentationTraceSources.MarkupSource.Switch.Level = SourceLevels.All;
            PresentationTraceSources.NameScopeSource.Listeners.Add(new ConsoleTraceListener());
            PresentationTraceSources.NameScopeSource.Switch.Level = SourceLevels.All;
        }

        double originalWidth = 0.0;
        double originalHeight = 0.0;
        double originalLeft = 0.0;
        double originalTop = 0.0;
        Point ptStartDrag;

        private void INT_dummySpace_MouseDown(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            Window4 resWindow = Window.GetWindow(sender as DependencyObject) as Window4;
            UIElement dragElement = sender as UIElement;

            originalLeft = resWindow.Left;
            originalTop = resWindow.Top;
            originalWidth = resWindow.Width;
            originalHeight = resWindow.Height;

            ptStartDrag = e.GetPosition(dragElement);
            dragElement.CaptureMouse();
        }


        private void INT_dummySpace_MouseMove(object sender, System.Windows.Input.MouseEventArgs e)
        {
            UIElement dragElement = sender as UIElement;
            Window4 resWindow = Window.GetWindow(sender as DependencyObject) as Window4;

            if (dragElement.IsMouseCaptured)
            {
                Point ptMoveDrag = e.GetPosition(dragElement);

                if (resWindow.Dock == Dock.Right)
                {
                    if (resWindow.Width + (ptMoveDrag.X - ptStartDrag.X) < 4.0)
                        resWindow.Width = 4.0;
                    else
                        resWindow.Width += ptMoveDrag.X - ptStartDrag.X;
                }
                else if (resWindow.Dock == Dock.Bottom)
                {
                    if (resWindow.Height + (ptMoveDrag.Y - ptStartDrag.Y) < 4.0)
                        resWindow.Height = 4.0;
                    else
                        resWindow.Height += ptMoveDrag.Y - ptStartDrag.Y;
                }
                else if (resWindow.Dock == Dock.Left)
                {
                    if (resWindow.Width - (ptMoveDrag.X - ptStartDrag.X) < 4)
                    {
                        resWindow.Left = originalLeft + originalWidth - 4;
                        resWindow.Width = 4;
                    }
                    else
                    {
                        resWindow.Left += ptMoveDrag.X - ptStartDrag.X;
                        resWindow.Width -=  ptMoveDrag.X - ptStartDrag.X;
                    }
                }
                else if (resWindow.Dock == Dock.Top)
                {
                    if (resWindow.Height - (ptMoveDrag.Y - ptStartDrag.Y) < 4)
                    {
                        resWindow.Top = originalTop + originalHeight - 4;
                        resWindow.Height = 4;
                    }
                    else
                    {
                        resWindow.Top += ptMoveDrag.Y - ptStartDrag.Y;
                        resWindow.Height -= ptMoveDrag.Y - ptStartDrag.Y;
                    }
                }
            }
        }

        private void INT_dummySpace_MouseUp(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            UIElement dragElement = sender as UIElement;
            dragElement.ReleaseMouseCapture();
        }



    }
}
/* $Id: pack.h,v 1.11 2009/01/21 16:47:00 arif Exp $ $Revision: 1.11 $ */
/* vim:set shiftwidth=4 ts=8: */

/**********************************************************
*      This software is part of the graphviz package      *
*                http://www.graphviz.org/                 *
*                                                         *
*            Copyright (c) 1994-2004 AT&T Corp.           *
*                and is licensed under the                *
*            Common Public License, Version 1.0           *
*                      by AT&T Corp.                      *
*                                                         *
*        Information and Software Systems Research        *
*              AT&T Research, Florham Park NJ             *
**********************************************************/



#ifndef _PACK_H
#define _PACK_H 1

#ifdef __cplusplus
extern "C" {
#endif

#include "types.h"

/* Type indicating granularity and method 
 *  l_undef  - unspecified
 *  l_node   - polyomino using nodes and edges
 *  l_clust  - polyomino using nodes and edges and top-level clusters
 *             (assumes ND_clust(n) unused by application)
 *  l_graph  - polyomino using graph bounding box
 *  l_hull   - polyomino using convex hull (unimplemented)
 *  l_tile   - tiling using graph bounding box (unimplemented)
 *  l_bisect - alternate bisection using graph bounding box (unimplemented)
 */
    typedef enum { l_undef, l_clust, l_node, l_graph } pack_mode;

    typedef struct {
#ifdef UNIMPLEMENTED
	float aspect;		/* desired aspect ratio */
#endif
	unsigned int margin;	/* margin left around objects, in points */
	int doSplines;		/* use splines in constructing graph shape */
	pack_mode mode;		/* granularity and method */
	boolean *fixed;		/* fixed[i] == true implies g[i] should not be moved */
    } pack_info;
#ifdef GVDLL
#define extern __declspec(dllexport)
#else
#define extern
#endif

/*visual studio*/
#ifdef WIN32_DLL
#ifndef GVC_EXPORTS
#define extern __declspec(dllimport)
#endif
#endif
/*end visual studio*/

    extern point *putGraphs(int, Agraph_t **, Agraph_t *, pack_info *);
    extern int packGraphs(int, Agraph_t **, Agraph_t *, pack_info *);
    extern int packSubgraphs(int, Agraph_t **, Agraph_t *, pack_info *);
    extern int pack_graph(int, Agraph_t **, Agraph_t *, boolean*);
    extern pack_mode getPackMode(Agraph_t * g, pack_mode dflt);
    extern int getPack(Agraph_t *, int not_def, int dflt);

    extern int isConnected(Agraph_t *);
    extern Agraph_t **ccomps(Agraph_t *, int *, char *);
    extern Agraph_t **pccomps(Agraph_t *, int *, char *, boolean *);
    extern int nodeInduce(Agraph_t *);
#undef extern
#ifdef __cplusplus
}
#endif
#endif

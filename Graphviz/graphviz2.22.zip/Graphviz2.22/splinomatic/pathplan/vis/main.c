#include <stdio.h>
#include "visibility.h"

main ()
{
    int    i, j;
    int    n;
    point* pts;
    int*   next;
    array2 arr;
    point  p;

    scanf ("%d\n", &n);
    pts = (point*)malloc(n*sizeof(point));
    next = (int*)malloc(n*sizeof(int));

    for (i = 0; i < n; i++)
      scanf ("%lf %lf\n", &pts[i].x, &pts[i].y);
      
    for (i = 0; i < n; i++)
      scanf ("%d\n", &next[i]);
      
    arr = vis (n, pts, next);

    for (i = 0; i < n; i++)
      for (j = 0; j < n; j++)
        printf ("%f\n", arr[i][j]);

    exit (0);
}

#include <pathgeom.h>
void Ptriangulate(Ppoly_t *polygon, void (*fn)(void *closure, Ppoint_t tri[]), void *vc);

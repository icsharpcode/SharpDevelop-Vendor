#pragma prototyped

#ifndef _PATHUTIL_INCLUDE
#define _PATHUTIL_INCLUDE
#include <pathplan.h>

#ifndef FALSE
#define FALSE	0
#define NOT(x)	(!(x))
#define TRUE	(NOT(FALSE))
#endif

typedef double COORD;
extern COORD area2 (Ppoint_t, Ppoint_t, Ppoint_t);
extern COORD dist2 (Ppoint_t, Ppoint_t);
extern int intersect(Ppoint_t a,Ppoint_t b,Ppoint_t c,Ppoint_t d);

int	in_poly(Ppoly_t argpoly, Ppoint_t q);
Ppoly_t	copypoly(Ppoly_t);
void	freepoly(Ppoly_t);

#endif

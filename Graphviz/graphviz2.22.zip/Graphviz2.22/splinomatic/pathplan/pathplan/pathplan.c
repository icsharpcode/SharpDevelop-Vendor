#pragma prototyped

#ifndef _PATH_INCLUDE
#define _PATH_INCLUDE

#include <pathgeom.h>

/* find shortest euclidean path within a simple polygon */
extern int Pshortestpath(Ppoly_t *boundary, Ppoint_t endpoints[2],
	Ppolyline_t *output_route);

/* fit a spline to an input polyline, without touching barrier segments */
extern int Proutespline (Pedge_t *barriers, int n_barriers,
	Ppolyline_t input_route, Pvector_t endpoint_slopes[2],
	Ppolyline_t *output_route);

/* utility function to convert from a set of polygonal obstacles to barriers */
extern int Ppolybarriers(Ppoly_t **polys, int npolys, Pedge_t **barriers, int *n_barriers);

#endif

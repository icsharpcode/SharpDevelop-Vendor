#pragma prototyped

#ifndef _SOLVERS_INCLUDE
#define _SOLVERS_INCLUDE

extern int solve3 (double *, double *);
extern int solve2 (double *, double *);
extern int solve1 (double *, double *);

#endif

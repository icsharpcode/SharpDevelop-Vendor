#pragma prototyped

#ifndef _PATHGEOM_INCLUDE
#define _PATHGEOM_INCLUDE
typedef struct Pxy_t {
    double x, y;
} Pxy_t;

typedef struct Pxy_t Ppoint_t;
typedef struct Pxy_t Pvector_t;

typedef struct Ppoly_t {
    Ppoint_t *ps;
    int pn;
} Ppoly_t;

typedef Ppoly_t Ppolyline_t;

typedef struct Pedge_t {
    Ppoint_t a, b;
} Pedge_t;

/* opaque state handle for visibility graph operations */
typedef struct vconfig_s vconfig_t;
#endif
